/* Sebastian Nelson CS 300 Project Two - Enhanced
 * This program loads course information from a separate file (sample_courses.csv), stores the courses in an ordered map, prints the courses in
 * order (Alphabet), and searches for individual course details. */

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

struct Course {
    std::string code;
    std::string title;
    std::vector<std::string> prerequisites;
};

class CoursePlanner {
public:
    // Loads and validates course records from the CSV input file.
    bool loadData(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cout << "Error: Unable to open file \"" << filename << "\".\n";
            return false;
        }

        std::map<std::string, Course> loadedCourses;
        std::string line;
        std::size_t lineNumber = 0;
        std::size_t skippedRecords = 0;

        while (std::getline(file, line)) {
            ++lineNumber;
            line = trim(line);

            if (line.empty()) {
                continue;
            }

            Course course;
            std::string errorMessage;
            if (!parseCourse(line, course, errorMessage)) {
                std::cout << "Warning: Line " << lineNumber << " skipped: "
                          << errorMessage << "\n";
                ++skippedRecords;
                continue;
            }

            const auto [iterator, inserted] =
                loadedCourses.emplace(course.code, course);

            if (!inserted) {
                std::cout << "Warning: Duplicate course code " << course.code
                          << " on line " << lineNumber
                          << "; the newer record replaced the earlier one.\n";
                iterator->second = course;
            }
        }

        if (loadedCourses.empty()) {
            std::cout << "Error: No valid course records were found.\n";
            return false;
        }

        courses_ = std::move(loadedCourses);
        std::cout << courses_.size() << " course(s) loaded successfully";
        if (skippedRecords > 0) {
            std::cout << "; " << skippedRecords << " invalid record(s) skipped";
        }
        std::cout << ".\n";

        reportMissingPrerequisites();
        return true;
    }

    // std::map keeps the keys ordered, so it may print an ordered list (Alphabet).
    void printCourseList() const {
        if (!hasData()) {
            printLoadReminder();
            return;
        }

        std::cout << "\nCourse List\n"
                  << "-----------\n";
        for (const auto& [code, course] : courses_) {
            std::cout << code << ", " << course.title << '\n';
        }
    }

    // Map lookup has an O(log n) average tree-search speed.
    void printCourseInfo(const std::string& requestedCode) const {
        if (!hasData()) {
            printLoadReminder();
            return;
        }

        const std::string code = toUpper(trim(requestedCode));
        if (code.empty()) {
            std::cout << "Error: Please enter a course code.\n";
            return;
        }

        const auto iterator = courses_.find(code);
        if (iterator == courses_.end()) {
            std::cout << "Course \"" << code << "\" was not found.\n";
            return;
        }

        const Course& course = iterator->second;
        std::cout << "\n" << course.code << ", " << course.title << '\n';
        std::cout << "Prerequisites: ";

        if (course.prerequisites.empty()) {
            std::cout << "None\n";
            return;
        }

        for (std::size_t index = 0; index < course.prerequisites.size(); ++index) {
            std::cout << course.prerequisites[index];
            if (index + 1 < course.prerequisites.size()) {
                std::cout << ", ";
            }
        }
        std::cout << '\n';
    }

    [[nodiscard]] bool hasData() const {
        return !courses_.empty();
    }

private:
    std::map<std::string, Course> courses_;

    static std::string trim(const std::string& value) {
        const auto first = std::find_if_not(
            value.begin(), value.end(),
            [](unsigned char character) { return std::isspace(character); });

        if (first == value.end()) {
            return "";
        }

        const auto last = std::find_if_not(
            value.rbegin(), value.rend(),
            [](unsigned char character) { return std::isspace(character); })
                              .base();

        return std::string(first, last);
    }

    static std::string toUpper(std::string value) {
        std::transform(
            value.begin(), value.end(), value.begin(),
            [](unsigned char character) {
                return static_cast<char>(std::toupper(character));
            });
        return value;
    }

    static bool parseCourse(const std::string& line,
                            Course& course,
                            std::string& errorMessage) {
        std::stringstream stream(line);
        std::string field;
        std::vector<std::string> fields;

        while (std::getline(stream, field, ',')) {
            fields.push_back(trim(field));
        }

        if (fields.size() < 2) {
            errorMessage = "each record must contain a course code and title";
            return false;
        }

        course.code = toUpper(fields[0]);
        course.title = fields[1];

        if (course.code.empty()) {
            errorMessage = "course code is missing";
            return false;
        }

        if (course.title.empty()) {
            errorMessage = "course title is missing";
            return false;
        }

        for (std::size_t index = 2; index < fields.size(); ++index) {
            const std::string prerequisite = toUpper(fields[index]);
            if (!prerequisite.empty()) {
                course.prerequisites.push_back(prerequisite);
            }
        }

        return true;
    }

    void reportMissingPrerequisites() const {
        for (const auto& [code, course] : courses_) {
            for (const std::string& prerequisite : course.prerequisites) {
                if (courses_.find(prerequisite) == courses_.end()) {
                    std::cout << "Warning: " << code
                              << " references unknown prerequisite "
                              << prerequisite << ".\n";
                }
            }
        }
    }

    static void printLoadReminder() {
        std::cout << "No course data is loaded. Select option 1 first.\n";
    }
};

void showMenu() {
    std::cout << "\nWelcome to the Course Planner\n"
              << "1. Load course data\n"
              << "2. Print course list\n"
              << "3. Print course information\n"
              << "9. Exit\n";
}

int main() {
    CoursePlanner planner;
    std::string input;

    while (true) {
        showMenu();
        std::cout << "Enter an option: ";

        if (!std::getline(std::cin, input)) {
            std::cout << "\nInput ended. Exiting Course Planner.\n";
            break;
        }

        if (input == "1") {
            std::cout << "Enter the course data filename: ";
            std::string filename;
            std::getline(std::cin, filename);
            planner.loadData(filename);
        } else if (input == "2") {
            planner.printCourseList();
        } else if (input == "3") {
            std::cout << "Enter the course code: ";
            std::string code;
            std::getline(std::cin, code);
            planner.printCourseInfo(code);
        } else if (input == "9") {
            std::cout << "Thank you for using the Course Planner!\n";
            break;
        } else {
            std::cout << "\"" << input << "\" is not a valid option.\n";
        }
    }

    return 0;
}
