/*Sebastian Nelson
16 April 2025
Project 2 CS-300
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;
//Structre fo course information
struct Course {
	string code;
	string title;
	vector <string> prerequisites;
};
//Map to store courses
map <string, Course> courseMap;

string toUpper(string str) {
	transform(str.begin(), str.end(), str.begin(), ::toupper);
	return str;
}
//Load course data from a selected file to input into coursemap
void loadData(const string& filename) {
	courseMap.clear();
	ifstream file(filename);

	if (!file) {
		cout << "Error: Unable to open file \"" << filename << "\".\n";
		return;
	}

	string line;
	while (getline(file, line)) {
		stringstream ss(line);
		string code, title, prereq;

		getline(ss, code, ',');
		getline(ss, title, ',');

			Course course;
		course.code = toUpper(code);
		course.title = title;

		while (getline(ss, prereq, ',')) {
			course.prerequisites.push_back(toUpper(prereq));
		}
		courseMap[course.code] = course;
	}
	cout << "Courses loaded successfull,\n";
}
//Print the list in aphanumeric order
void printCourseList() {
	if (courseMap.empty()) {
		cout << "No coursees can be loaded at this time. Please load data .\n";
		return;
	}
	cout << "\nCourse List:\n";
	for (const auto& pair : courseMap) {
		cout << pair.second.code << "," << pair.second.title << endl;
	}
}
//print information and prereq for a particular courses
void printCourseInfo(const string& courseCode) {
	string code = toUpper(courseCode);

	if (courseMap.find(code) == courseMap.end()) {
		cout << "Course\"" << code << "\" not found.\n";
		return;
	}
	Course course = courseMap[code];
	cout << course.code << "," << course.title << endl;

	cout << "Prerequisistes: ";
	if (course.prerequisites.empty()) {
		cout << "None" << endl;
	}else {
		for (size_t i = 0;i < course.prerequisites.size(); ++i) {
			cout << course.prerequisites[i];
			if (i != course.prerequisites.size() - 1) cout << ",";
	}
		cout << endl;
	}
}
//Display main menu
void showMenu() {
	cout << "\nWelcome to the course planner." << endl;
	cout << "1. Load Data Structure." << endl;
	cout << "2. Print Course List." << endl;
	cout << "3. Print Course." << endl;
	cout << "9. Exit" << endl;
}
//Main function to run course planner
int main() {
	string input;
	bool running = true;

	while (running) {
		showMenu();
		cout << "How would you like to begin? ";
		getline(cin, input);

		if (input == "1") {
			cout << "Enter the file name to load: ";
			string filename;
			getline(cin, filename);
			loadData(filename);
		}
		else if (input == "2") {
			printCourseList();
		}
		else if (input == "3") {
			cout << "What course do you whant to know more about?";
			string code;
			getline(cin, code);
			printCourseInfo(code);
		}
		else if (input == "9") {
			cout << "Thank you for using our course planner!" << endl;
			running = false;
		}
		else {
			cout << input << " is nat a valid option." << endl;
		}
	}
	return 0;
}