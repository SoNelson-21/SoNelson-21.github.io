import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/*Starts the Top Five Destination List application.*/
public class TopFiveDestinationList {

    /*Main method that launches the application.*/
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            setSystemLookAndFeel();

            TopDestinationListFrame frame =
                    new TopDestinationListFrame();

            frame.setVisible(true);
        });
    }

    /*Applies the computer's default visual style.*/
    private static void setSystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception exception) {
            System.err.println(
                    "Unable to apply the system look and feel."
            );
        }
    }
}

/*Main window that displays the destination list.*/
class TopDestinationListFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final int WINDOW_WIDTH = 900;
    private static final int WINDOW_HEIGHT = 750;

    private final DefaultListModel<TextAndIcon> listModel;

    /*Creates and configures the main application window.*/
    public TopDestinationListFrame() {
        super("Top Five Destination List");

        listModel = new DefaultListModel<>();

        configureWindow();
        createHeader();
        loadDestinations();
        createDestinationList();
    }

    /*Configures the window size, layout, and close behavior.*/
    private void configureWindow() {
        setDefaultCloseOperation(
                WindowConstants.EXIT_ON_CLOSE
        );

        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
    }

    /*Creates the heading displayed at the top of the window*/
    private void createHeader() {
        JLabel nameLabel = new JLabel(
                "Sebastian Nelson's Top Five Destinations",
                SwingConstants.CENTER
        );

        nameLabel.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        nameLabel.setForeground(Color.BLACK);

        nameLabel.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        10,
                        15,
                        10
                )
        );

        add(nameLabel, BorderLayout.NORTH);
    }

    /*Adds the five destinations and their images.*/
    private void loadDestinations() {
        addDestinationNameAndPicture(
                "1. Bangkok, Thailand. "
                        + "A beautiful city located along the "
                        + "Chao Phraya River Delta.",
                loadImage(
                        "/resources/"
                                + "128px-Bangkok_skytrain_sunset.jpg"
                )
        );

        addDestinationNameAndPicture(
                "2. London, United Kingdom. "
                        + "A wonderful city that is rich with history.",
                loadImage(
                        "/resources/"
                                + "128px-London_Skyline_"
                                + "(125508655).jpeg"
                )
        );

        addDestinationNameAndPicture(
                "3. Dubai, United Arab Emirates. "
                        + "A large and amazing city known for "
                        + "its modern architecture.",
                loadImage(
                        "/resources/"
                                + "256px-Dubai_Skylines_at_night_"
                                + "(Pexels_3787839).jpg"
                )
        );

        addDestinationNameAndPicture(
                "4. Bali, Indonesia. "
                        + "A stunning island with a vibrant art scene.",
                loadImage(
                        "/resources/"
                                + "128px-Pura_Ulun_Danu_Bratan,_2022.jpg"
                )
        );

        addDestinationNameAndPicture(
                "5. Paris, France. "
                        + "A wonderful city that is a major center "
                        + "for business, art, and fashion.",
                loadImage(
                        "/resources/"
                                + "256px-La_Tour_Eiffel_vue_de_la_"
                                + "Tour_Saint-Jacques,_Paris_"
                                + "août_2014_(2).jpg"
                )
        );
    }

    /*Creates the destination list and custom renderer.*/
    private void createDestinationList() {
        JList<TextAndIcon> destinationList =
                new JList<>(listModel);

        destinationList.setCellRenderer(
                new TextAndIconListCellRenderer(8)
        );

        destinationList.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        destinationList.setFixedCellHeight(145);

        JScrollPane scrollPane =
                new JScrollPane(destinationList);

        add(scrollPane, BorderLayout.CENTER);
    }

    /*Adds one destination to the list model.*/
    private void addDestinationNameAndPicture(
            String text,
            Icon icon) {

        TextAndIcon destination =
                new TextAndIcon(text, icon);

        listModel.addElement(destination);
    }

    /*Loads an image from the resources folder.*/
    private ImageIcon loadImage(String imagePath) {
        URL imageUrl = getClass().getResource(imagePath);

        if (imageUrl == null) {
            System.err.println(
                    "Image not found: " + imagePath
            );

            return new ImageIcon();
        }

        return new ImageIcon(imageUrl);
    }
}

/*Stores destination text and an image.*/
final class TextAndIcon {

    private final String text;
    private final Icon icon;

    /*Creates an item containing destination text and an icon.*/
    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }
}

/*Controls how each destination appears in the list.*/
class TextAndIconListCellRenderer
        extends JLabel
        implements ListCellRenderer<TextAndIcon> {

    private static final long serialVersionUID = 1L;

    private static final Border NO_FOCUS_BORDER =
            new EmptyBorder(1, 1, 1, 1);

    private static final int IMAGE_WIDTH = 180;
    private static final int IMAGE_HEIGHT = 120;

    private final Border insideBorder;

    /*Creates a renderer with no padding.*/
    public TextAndIconListCellRenderer() {
        this(0);
    }

    /*Creates a renderer with equal padding.*/
    public TextAndIconListCellRenderer(int padding) {
        this(
                padding,
                padding,
                padding,
                padding
        );
    }

    /*Creates the renderer with custom padding.*/
    public TextAndIconListCellRenderer(
            int topPadding,
            int rightPadding,
            int bottomPadding,
            int leftPadding) {

        insideBorder =
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                Color.GRAY,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                topPadding,
                                leftPadding,
                                bottomPadding,
                                rightPadding
                        )
                );

        setOpaque(true);
        setIconTextGap(15);
        setVerticalAlignment(SwingConstants.CENTER);
        setFont(new Font("Arial", Font.PLAIN, 15));
    }

    /*Configures the appearance of each destination.*/
    @Override
    public Component getListCellRendererComponent(
            JList<? extends TextAndIcon> list,
            TextAndIcon value,
            int index,
            boolean isSelected,
            boolean hasFocus) {

        setText(
                "<html><body style='width: 560px;'>"
                        + value.getText()
                        + "</body></html>"
        );

        setIcon(scaleIcon(value.getIcon()));

        if (isSelected) {
            setBackground(
                    list.getSelectionBackground()
            );

            setForeground(
                    list.getSelectionForeground()
            );
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder =
                    UIManager.getBorder(
                            "List.focusCellHighlightBorder"
                    );
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(
                BorderFactory.createCompoundBorder(
                        outsideBorder,
                        insideBorder
                )
        );

        setComponentOrientation(
                list.getComponentOrientation()
        );

        setEnabled(list.isEnabled());

        return this;
    }

    /*Resizes destination images to a consistent size.*/
    private Icon scaleIcon(Icon icon) {
        if (!(icon instanceof ImageIcon)) {
            return icon;
        }

        ImageIcon imageIcon = (ImageIcon) icon;

        if (imageIcon.getIconWidth() <= 0) {
            return imageIcon;
        }

        Image scaledImage =
                imageIcon.getImage().getScaledInstance(
                        IMAGE_WIDTH,
                        IMAGE_HEIGHT,
                        Image.SCALE_SMOOTH
                );

        return new ImageIcon(scaledImage);
    }
}