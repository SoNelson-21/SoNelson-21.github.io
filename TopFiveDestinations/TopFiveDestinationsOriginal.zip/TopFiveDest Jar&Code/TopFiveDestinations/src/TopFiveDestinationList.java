import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    /**
     * @wbp.parser.entryPoint
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();

        // Created a label with the name "Sebastian Nelson"
        JLabel nameLabel = new JLabel("Sebastian Nelson", JLabel.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Set a larger font for the name
        nameLabel.setForeground(Color.BLACK); // You can customize the color

        // Added the label to the top of the window 
        add(nameLabel, BorderLayout.NORTH);
        
        //Make updates to your top 5 list below. Import the new image files to resources directory.
        //Inserted names and a brief.
        //I then added images to the resource folder and copied them into the document.
        addDestinationNameAndPicture("1. Bangkok, Thailand. A beautiful city that sits on Chao Phraya River Delta.", new ImageIcon(getClass().getResource("/resources/128px-Bangkok_skytrain_sunset.jpg")));
        addDestinationNameAndPicture("2. London, United Kingdom. A wonderful city with that is rich with history.", new ImageIcon(getClass().getResource("/resources/128px-London_Skyline_(125508655).jpeg")));
        addDestinationNameAndPicture("3. Dubai, United Arab Emirates. A large and amazing city known for its modern Architecture", new ImageIcon(getClass().getResource("/resources/256px-Dubai_Skylines_at_night_(Pexels_3787839).jpg")));
        addDestinationNameAndPicture("4. Bali, Indonesia. A stunning island with a vibrant art scene", new ImageIcon(getClass().getResource("/resources/128px-Pura_Ulun_Danu_Bratan,_2022.jpg")));
        addDestinationNameAndPicture("5. Paris, France. A wonderful city that is a major center for business and fashion.", new ImageIcon(getClass().getResource("/resources/256px-La_Tour_Eiffel_vue_de_la_Tour_Saint-Jacques,_Paris_août_2014_(2).jpg")));
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);

        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }
    //Changed the boarder from empty to Cyan
    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createLineBorder(Color.CYAN, 2);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}